# -*- coding: utf-8 -*-
"""
Created on Sat Aug  6 18:24:51 2022

Features .py package for CQF Final Project.

Please, attach this .py file in the same folder to read it properly in the
final project notebook.

@author: FRANK YGNACIO ROSAS
"""

# base packages
import talib # version 0.4.21.
import random
import numpy as np
import pandas as pd
from tqdm import tqdm
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import f1_score
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import TimeSeriesSplit

# extra packages 
import pprint
import matplotlib as mpl
from minisom import MiniSom
import matplotlib.patches as mpatches
from sklearn.metrics import silhouette_score
from sklearn.metrics import silhouette_samples
from matplotlib.ticker import FixedLocator, FixedFormatter

# LSTM Keras packages
from keras.layers import Dense
from keras.layers import LSTM
from keras.layers import Dropout
from keras.models import Sequential


##################################################### FEATURES STAGE #####################################################
class Features(object):
    
    def __init__(self, dataframe):
        self.df = dataframe
        
        self.o = self.df['Open']
        self.h = self.df['High']
        self.l = self.df['Low']
        self.c = self.df['Close']
        self.v = self.df['Volume']
        
        # dict params for features params (each param should be a list)
        FeaturesParams = {
            "sar_maxval": [0.2], # fixed cause' no sig. change with other values
            "rsi_window": None,
            "sma_window": None,
            "macd_windows": None,
            "atr_window": None,
            "bb_window_std": None,
            "corwin_window": [1],
            "qm_window": [21]
            }
        self.FeaturesParams = FeaturesParams        
    
    #################################################################################
    ############################## Base General Methods #############################
    #################################################################################
    
    # Bollinger Bands Logic
    def __BBLOGIC__(self, upperband, middleband, lowerband, price):
        """
        Bollinger Band Logic (signal generation)

        Description:
            Builds a signal from the BBands base information (upper/mid/lower band). 

        Parameters:
            - 'upperband' :: pd.core.Series/pd.core.DataFrame with shape (..., 1).
                > Upper band computed of the BBand.
            - 'lowerband' :: pd.core.Series/pd.core.DataFrame with shape (..., 1).
                > lower band computed of the BBand.                
            - 'middleband' :: pd.core.Series/pd.core.DataFrame with shape (..., 1).
                > middle band computed of the BBand (eq. to SMA).                 
            - 'price' :: pd.core.Series/pd.core.DataFrame with shape (..., 1).
                > adjusted close price from the base asset.                 
        
        Bollinger Band Signal Logic (pseudo-code):
            
            series = 0
            
            if price > upper band:
                series append -1
            if price < lower band:
                series append 1
            else:
                if lower band < price <= upper band:
                    series append -0.5
                else:
                    series append 0.5
             return cumulative sum (series * weights), where  lowerLimit < weights < upperLimit
             
             Here, lowerLimit = 1 and upperLimirt = 2
             
        Output:
            - pd.core.Series with signal based on the logic defined above.

        References:
            - Gonzales, H.; Ygnacio, F.; Soldevilla, A.; Vasquez, W. (April, 2021). 
              'EnigmX: the investment strategies factory'. 
              https://www.docdroid.net/txvET7H/enigmx-whitepaper-en-pdf   
            - Investopedia Team. (July 19, 2022). 'The basic of Bollinger Bands'. 
              https://www.investopedia.com/articles/technical/102201.asp
        """

        # change base input to arrays
        upperArray, middArray, lowerArray, priceArray = \
            upperband.values, middleband.values, lowerband.values, price.values

        # error mssge 
        mssg = '    ::::::>>> Shape Error! ~ B.Bollinger Indicator Error: shapes are different.'

        # checking dimensionality
        assert upperArray.shape[0] == middArray.shape[0] == lowerArray.shape[0] == priceArray.shape[0], mssg

        # base length of series
        outputSignal = np.zeros(len(upperArray))

        # nan default values
        outputSignal[:] = np.nan

        # first condition: down reversal signal
        outputSignal[priceArray > upperArray] = -1

        # second condition: up reversal signal
        outputSignal[priceArray < lowerArray] = 1
        
        # third condition: mid-down reversal signal
        outputSignal[(middArray < priceArray) & (priceArray <= upperArray)] = -0.5
        
        # fourth condition: mid-up reversal signal
        outputSignal[(middArray >= priceArray) & (priceArray > lowerArray)] = 0.5
        
        # weights definition
        w = (priceArray/lowerArray) 
        w[w>2] = 2
        w[w<1] = 1 
        
        # weighting of output signal
        outputSignal = outputSignal * w
        
        # return cumulative sum of series 
        return pd.Series(outputSignal, index=price.index).cumsum()    
    
    # Alpha's Rolling Min
    def __tsmin__(self, data, window=10):
        return data.rolling(window).min()    
    
    # Alpha's Delta (difference)
    def __delta__(self, data, period=1):
        return data.diff(period)    
    
    # Alpha's Delay 
    def __delay__(self, data, period=1):
        return data.shift(period) 
    
    # Alpha's VWAP
    def __vwap__(self, c, v):
        return np.cumsum(c * v) / np.cumsum(v)
    
    # Alpha's Time Series Scaling
    def __scale__(self, data, factor=1):
        return data.mul(factor).div(np.abs(data).sum())    
    
    # Alpha's Rolling Correlation
    def __correlation__(self, a, b, window=10):
        return a.rolling(window).corr(b)    

    ##############################################################################
    ############################ Technical Indicators ############################
    ##############################################################################
    
    # General Indicator : Parabolic SAR 
    def __PSAR__ (self, maxval, acceleration=0.02):
        return talib.SAR(
            self.h, 
            self.l, 
            acceleration=acceleration, 
            maximum=maxval
            )
    
    # Momentum Indicator #1 : RSI 
    def __RSI__(self, window):
        return talib.RSI(self.c, timeperiod = window) 
    
    # Momentum Indicator #2 : SMA
    def __SMA__(self, window, base_series):
        return talib.SMA(base_series, timeperiod=window) 
    
    # Momentum Indicator #3 : MACD
    def __MACD__(self, window_short, window_long):
        return talib.MACD(
            self.c, 
            fastperiod=window_short, 
            slowperiod=window_long
        )[1] # we'll use only the MACD signal
        
    # Volatility Indicator #1 : ATR
    def __ATR__(self, window):
        return talib.ATR(
            self.h, 
            self.l, 
            self.c,
            timeperiod = window
        ) 
        
    # Volatility Indicator #2 : BBand Logic
    def __BBAND__(self, window, stdup, stddown):
        upperband, middleband, lowerband = talib.BBANDS(
            self.c, 
            timeperiod=window, 
            nbdevup=stdup,      
            nbdevdn=stddown,     
            matype=0      
            )
        return self.__BBLOGIC__(upperband, middleband, lowerband, self.c)
         
    # Volume Indicator #1 : Chaikin A/D Line
    def __CHAIKIN__(self):
        return talib.AD(self.h, self.l, self.c, self.v)
        
    # Volume Indicator #2 : On Balance Volume Indicator
    def __OBV__(self):
        return talib.OBV(self.c, self.v)
    
    ##############################################################################
    ############################### Alpha Factors ################################
    ##############################################################################    
    
    # Alpha 9
    def __alpha9__(self, c):
        if min(c.diff(1)) > 0:
            return c.diff(1)
        elif max(c.diff(1)) < 0:
            return c.diff(1)
        else: return -1*c.diff(1)    
    
    # Alpha 24
    def __alpha24__(self, c):
        conditional = \
            self.__delta__(self.__SMA__(100, c), 100) / self.__delay__(c, 100) <= 0.05
        alpha24 = -1 * self.__delta__(c, 3)
        alpha24[conditional] = (c - self.__tsmin__(c, 100)) * -1
        return alpha24            
    
    # Alpha 32
    def __alpha32__(self, c, v):
        vwap = self.__vwap__(c, v)
        alpha32 = self.__scale__(((self.__SMA__(7, c) / 7) - c)) \
        + (20 * self.__scale__(self.__correlation__(vwap, self.__delay__(c, 5),230)))
        return alpha32
        
    # Alpha 41
    def __alpha41__(self, h, l, c, v):
        vwap = self.__vwap__(c, v)
        return pow((h * l), 0.5) - vwap
    
    # Alpha 101
    def __alpha101__(self, o, h, l, c):
        return (c - o)/((h - l) + 0.001)
    
    ##############################################################################
    ######################### Microstructural Factors ############################
    ##############################################################################    
    
    # First Generation MS Factor - Crowin Schultz Bid Ask Spread (generates 2 factors!)
    def __corwinSchultz__(self, h, l, mean_win=1):
        """
        Corwin Schultz Estimator
        
        Description:
            Generates a bid-ask spread estimator.
            Additionally, generates the Becker Parkinson High-Low Volatility.
            
        Parameters:
            - 'h' :: pd.core.Series/pd.core.DataFrame with shape (..., 1).
                > High prices of the asset time series.
            - 'l' :: pd.core.Series/pd.core.DataFrame with shape (..., 1).
                > Low prices of the asset time series.
            - 'mean_win' :: positive integer value.
                > time frame to evaluate liquidity/volatility.
            
        Output:
            - pd.core.Series with corwin-schultz bid-ask spread (liquidity factor).
            - pd.core.Series with corwin-schultz volatility (eq. to Becker Parkinson H-L volatility).

        References:
            - Corwin, S.; Schultz, P. A Simple Way to Estimate Bid-Ask Spreads from Daily High and Low Prices.
              https://doi.org/10.1111/j.1540-6261.2012.01729.x.              
            - Gonzales, H.; Ygnacio, F.; Soldevilla, A.; Vasquez, W. (April, 2021). 
              'EnigmX: the investment strategies factory'. 
              https://www.docdroid.net/txvET7H/enigmx-whitepaper-en-pdf          
        """
        # computing beta
        hl=np.log(h/l)**2
        beta=hl.rolling(window=2).sum()
        beta=beta.rolling(window=mean_win).mean()
        # computing gamma
        h2=h.rolling(window=2).max()
        l2=l.rolling(window=2).min()
        gamma=np.log(h2/l2)**2
        # computing base alpha
        den = 3 - 2*2**.5
        alpha=(2**.5-1)*(beta**.5)/den - (gamma/den)**.5
        alpha[alpha<0]=0 # set negative alphas to 0 as CS suggest (p.727)
        # computing sigma (Becker Parkinson Volatility)
        kVol=(8/np.pi)**.5
        den=3-2*2**.5
        sigma=(2**(-.5)-1)*beta**.5/(kVol*den)+(gamma/(kVol**2*den))**.5
        sigma[sigma<0]=0
        # computing final spread
        spread=2*(np.exp(alpha)-1)/(1+np.exp(alpha))
        # return the sqrt root of spread and sigma to up-scale signal values 
        return np.sqrt(spread), np.sqrt(sigma)    
    
    # Second Generation MS Factor - Kyle's Lambda    
    def __kyleLambda__(self, c, v):
        """
        Kyle's Lambda 
        
        Description:
            Measure the impact on price-equilibrium of order flow.
            (here, the impact is an estimated since we are working with daily prices).
            
        Parameters:
            - 'c' :: pd.core.Series/pd.core.DataFrame with shape (..., 1).
                > Close prices of the asset time series.
            - 'v' :: pd.core.Series/pd.core.DataFrame with shape (..., 1).
                > Volume values of the asset time series.
                
        Output:
            - pd.core.Series with key's lambda liquidity factor.
            
        References:
            - Kyle, A. (Nov, 1985) Continous Auctions and Insider Trading. Econometrica. Vol 53, 6. 
              https://doi.org/10.2307/1913210
            - Gonzales, H.; Ygnacio, F.; Soldevilla, A.; Vasquez, W. (April, 2021). 
              'EnigmX: the investment strategies factory'. 
              https://www.docdroid.net/txvET7H/enigmx-whitepaper-en-pdf          
        """        
        d_p_t = c.diff()
        b = d_p_t.copy()
        b[b < 0] = -1
        b[b > 0] =  1
        b[b == 0] = 1
        lambda_k = (d_p_t**2) / (v * b)
        lambda_k[lambda_k < 0] = 0
        return np.cbrt(lambda_k)
    
    ##############################################################################
    ########################## Naive Quantmoon Factor ############################
    ##############################################################################    
    def __QMFactor__(self, h, l, v, window=21):
        """
        Naive factor developed by Quantmoon Technologies Org. 
        
        No description is attached.
        
        References:
            - Gonzales, H.; Ygnacio, F.; Soldevilla, A.; Vasquez, W. (April, 2021). 
              'EnigmX: the investment strategies factory'. 
              https://www.docdroid.net/txvET7H/enigmx-whitepaper-en-pdf            
        """
        return (l**2) * (v / h)
    
    ##############################################################################
    ###################### Main Method to Compute Features #######################
    ##############################################################################
    def compute_features(self, **kwargs):
        
        # ingesting default features and user input values 
        for (prop, default) in self.FeaturesParams.items():
            setattr(self, prop, kwargs.get(prop, default))        
        
        ########################## Technical Features ############################
        
        # computing SAR's (better with standard '0.2' maxval | useless trying other values)
        parabolicSars = {f'featSAR_{maxval}_val': 
                         self.__PSAR__(maxval) for maxval in self.sar_maxval}
        
        # computing RSI's
        rsis = {f'featRSI_{window}w': 
                self.__RSI__(window) for window in self.rsi_window}
        
        # computing SMA's
        smas = {f'featSMA_{window}w': 
                self.__SMA__(window, self.c) for window in self.sma_window}

        # computing MACD's
        macds = \
        {f'featMACD_{windows[0]}w_{windows[1]}w': 
         self.__MACD__(windows[0], windows[1]) for windows in self.macd_windows}

        # computing ATR's
        atrs = {f'featATR_{window}w': 
                self.__ATR__(window) for window in self.atr_window}
        
        # computing MACD's
        bbands = \
        {f'featBBS_{windowStd[0]}std_{windowStd[1]}w_{windowStd[1]}w': 
         self.__BBAND__(windowStd[0], windowStd[1], windowStd[1]) for windowStd in self.bb_window_std}
        
        # computing volume indicators (single time series : no input parameter required)
        chaikinLine, obvIndicator = {'featCHAIKIN': self.__CHAIKIN__()}, {'featOBV': self.__OBV__()}
        
        # getting all technical features in a single dictionary
        techfeaturesDict = \
        {**parabolicSars, **rsis, **smas, **macds, **atrs, **bbands, **chaikinLine, **obvIndicator}
        
        ########################### Alpha Factors ####################################
        
        # alpha 9
        alpha9 = self.__alpha9__(self.c)
        
        # alpha 24
        alpha24 = self.__alpha24__(self.c)
        
        # alpha 32
        alpha32 = self.__alpha32__(self.c, self.v)
        
        # alpha 41
        alpha41 = self.__alpha41__(self.h, self.l, self.c, self.v)
        
        # alpha 101
        alpha101 = self.__alpha101__(self.o, self.h, self.l, self.c)
        
        # getting all alpha factors in a single dictionary
        alphafeaturesDict = \
        {"featALPHA9": alpha9, "featALPHA24": alpha24, 
         "featALPHA32": alpha32, "featALPHA41": alpha41, 
         "featALPHA101":alpha101}
        
        ######################## Microstructural Features ##############################
        
        # Corwin Schultz Liq. & Becker Parkinson Volatility
        corwinschultz_, beckerparkison_ = \
        zip(*[self.__corwinSchultz__(self.h, self.l, meanWin) for meanWin in self.corwin_window])
        
        corwinschultz = \
        {f'featCORWINS_{idxMean[1]}mw': 
         corwinschultz_[idxMean[0]] for idxMean in enumerate(self.corwin_window)}
        
        beckerparkison = \
        {f'featBECKERP_{idxMean[1]}mw': 
         beckerparkison_[idxMean[0]] for idxMean in enumerate(self.corwin_window)}        
        
        # Kyle's Lambda 
        kylelambda = {"featKYLEL": self.__kyleLambda__(self.c, self.v)}
        
        # getting all microstructural features in a single dictionary
        microfeaturesDict = {**corwinschultz, **beckerparkison, **kylelambda}
         
        ############################## Naive Feature ################################
        
        # Quantmoon Feature
        qm_feature = \
        {f'featQM_{window}w': 
         self.__QMFactor__(self.h, self.l, self.v, window) for window in self.qm_window}
        
        # retuning general dictionary with all features
        return pd.DataFrame({**techfeaturesDict, **alphafeaturesDict, **microfeaturesDict, **qm_feature})
    
# SFI method for features parameters selection
def SFI_CQF(clf, X, y, nSplits, label_name='Label', penalized=True, scaling=True):
    """
    Description:
        This function is an updated version of the method proposed by Lopez de Prado (2018),
        called Single Feature Importance, a Feature Importance Isolated OOS technique.
        This version apply some changes to be useful to our dataset in the context of the CQF.
    Methodology:
        The SFI OOS method evaluates the performance of a given single feature
        in a Naive Classifier (i.e., no tunned). So, each feature of the 
        general dataset will be tested independently, finding its score (here, accuracy),
        and return a dataframe with its OOS score mean value for all the 'nSplits'. 
        Also, the method returns the standard deviation of this mean, 
        and its 'penalized mean' if it is asked (penalized=True). 
    Input:
        - clf: classifier object to be used as the base estimator
        - X: pd.DataFrame with the features to be tested in isolation
        - y: pd.DataFrame with the labels; one column should be 'label_name'
        - nSplits: int with the total splits to be used per feature in the evaluation.
        - label_name: str containing the name of the label 
        - penalized: boolean activated if we want to find its penalized mean score by std.
    Output:
        - pd.DataFrame of columns:
            > "meanImportance"
            > "stdImportance"
            > "penalizedMeanImp"
          dataframe index := features name
    """
    # defining a empty importance dataframe
    importance = pd.DataFrame(columns=["meanImportance", "stdImportance"])
    
    # definition of iter tqdm object
    iterTqdmObj =tqdm(X.columns)
    
    # setting iteration per feature
    for feature in iterTqdmObj:
        # adding message to progress bar
        iterTqdmObj.set_description(f"SFI | Processing - {feature}")
        # empty list to save the scores
        scores = []
        # definition of the temporal classifier to be updated at each new feature
        tempClf = clf
        # setting of the timeSeriesSplit object with the Number of Splits
        tscv = TimeSeriesSplit(n_splits=nSplits)
        # selecting the temporal dataframe with only the feature of the iteration
        temporalX = X[[feature]]
        # split given the temporal features dataset 'temporalX' with only one feature
        for train_index, test_index in tscv.split(temporalX):
            # feature training and testing set definition
            tempXTrain, tempXTest = temporalX.iloc[train_index], temporalX.iloc[test_index]
            # check if scaling is required for the user
            if scaling:
                # >> definition of base scaler object
                scaler = MinMaxScaler()                
                # >> fitting scaler with X train
                scaler.fit(tempXTrain)
                # >> transforming X test
                tempXTest = scaler.transform(tempXTest)
            # label training and testing set definition
            tempYTrain, tempYTest = y[label_name].iloc[train_index], y[label_name].iloc[test_index]
            # fitting the classifier with the temporal training dataset 
            fit = tempClf.fit(tempXTrain, tempYTrain)
            # computing the prediction using OOS test data
            pred = fit.predict(tempXTest)
            # finding the OOS score (fixed metric: accuracy) and appending its value
            score_ = f1_score(tempYTest, pred, average='micro')
            scores.append(score_)
        # filling the dataframe with the results for the given feature
        importance.loc[feature, 'meanImportance'] = np.array(scores).mean()
        importance.loc[feature, 'stdImportance'] = abs(np.array(scores).std())         
        importance.loc[feature, 'penalizedMeanImp'] = \
        importance.loc[feature, 'meanImportance'] - importance.loc[feature, 'stdImportance']
    return importance

def elbowKMeansIteration(dictAssetInfo, nClusters):
    """
    Function that allows to compute elbow assessment.
    
    Inputs:
        > dictAssetInfo: dcit with string key of name of asset, and value with the dataframe of features (rows: features, cols: dates)
        > nClusters: range object, or list, with the 'k' to test the KMeans
    """
    # elbow plot to find the optimal n clusters for both assets
    inertiaFdFeat, silhouetteFdFeat, fdKMeansPerK = {}, {}, {} 

    # iteration for asset 
    for assetName, dataFeat in dictAssetInfo.items():
        # scaler definition
        scaler = MinMaxScaler()
        # definition of X
        X = scaler.fit_transform(dataFeat)
        # definition of general info to save for each asset
        inertiaList, sScoresList, KMeansModels = [], [], []
        # iteration for each cluster required
        for n in nClusters:
            # KMeans initialization
            kmeans = KMeans(n_clusters=n)
            # KMeans fitting step
            kmeans.fit(X)
            # saving local information of asset based on k value
            inertiaList.append(kmeans.inertia_) 
            sScoresList.append(silhouette_score(dataFeat, kmeans.labels_)) # also silhouette for later use
            KMeansModels.append(kmeans)
        # saving final information of the asset for all k's
        inertiaFdFeat[assetName] = inertiaList 
        silhouetteFdFeat[assetName] = sScoresList
        fdKMeansPerK[assetName] = KMeansModels
    return inertiaFdFeat, silhouetteFdFeat, fdKMeansPerK

def plotSilhouette(silhouette_scores, kmeans_per_k, X, range_k, name, titleName, plotdim=(4,4), plotsize=(20,20)):
    """
    Base function to plot the Silhouette analysis.
    
    Inputs:
        > silhouette_scores: list with the sil. scores with length L
        > kmeans_per_k: all the k means model based on the K used; list of length L
        > X: base features dataset
        > range_k: range of K values tested; list of length L
        > name: of the category that defines the process (string)
        > titleName: a predefined title for the plot (string)
        > plotdim: tuple with integers representing the subplots; e.g., (4,4)
        > plotsize: tuple with integers representing the dimensions of the general plot; e.g., (20,20)
    """
    fig, ax = plt.subplots(
        nrows=plotdim[0], ncols=plotdim[1], 
        sharex=True, sharey=True, figsize=(plotsize[0], plotsize[1])
    )
    for k in range_k:
        plt.subplot(plotdim[0], plotdim[1], k-1)

        y_pred = kmeans_per_k[k-2].labels_
        silhouette_coefficients = silhouette_samples(X, y_pred)

        padding = len(X) // 30
        pos = padding
        ticks = []
        for i in range(k):
            coeffs = silhouette_coefficients[y_pred == i]
            #coeffs[coeffs<0] = 0
            coeffs.sort()
            color = mpl.cm.Spectral(i / k)
            plt.fill_betweenx(np.arange(pos, pos + len(coeffs)), 0, coeffs,
                              facecolor=color, edgecolor=color, alpha=0.7)
            ticks.append(pos + len(coeffs) // 2)
            pos += len(coeffs) + padding
        plt.gca().yaxis.set_major_locator(FixedLocator(ticks))
        plt.gca().yaxis.set_major_formatter(FixedFormatter(range(k)))
        plt.axvline(x=silhouette_scores[k-2], color="red", linestyle="--")
        plt.title("$k={}$".format(k), fontsize=16)
    fig.text(0.51, -0.005, 'Silhouette Coefficient', ha='center', fontsize=12, fontweight='bold')
    fig.text(-0.005, 0.51, 'Clusters', va='center', rotation='vertical', fontsize=12, fontweight='bold')
    fig.suptitle(f"Silhouette Coeff. Assessment - {titleName} | {name}", 
                 fontweight='semibold', fontsize=15, y=1.0025)
    plt.tight_layout()
    plt.show()   

    
    
def somAnalysis(X, baseFeaturesSet, 
                somDim = (10, 10), nIter = 10000, 
                learning_rate = 0.5, sigma=3, 
                plot = False, nameTitle=None):
    """
    Main Function to compute SOM map.
    
    Inputs:
        > X : dataframe, series or array with features for SOM
        > baseFeaturesSet: dataframe or series with features in same order of X.
        > somDim: tuple of integers with dimension for SOM matrix
        > nIter: integer meaning iterations to fit SOM
        > learning_rate: float meaning learning rate of the net
        > sigma: integer/float representing sigma for the learning process in the net.
        > plot: bool to plot the map
        > nameTitle: string to put in the title of the plot, if it is required.
    """
    # data scaling
    scaler = MinMaxScaler()
    X = scaler.fit_transform(X)
    # som initialization
    som = MiniSom(
        somDim[0], somDim[1], 
        X.shape[1], learning_rate=learning_rate, 
        sigma=sigma, random_seed=42
    )
    # initialization of random weights
    som.random_weights_init(X)
    
    # tranining SOM with nIter iterations
    som.train_batch(X, nIter, verbose=True)
    
    # plot if user required it
    if plot:
        print("*" * 35)
        assert nameTitle != None, "Please, set 'nameTitle' for correct plotting"
        # plot SOM map
        plt.figure(figsize=(20, 10))
        counterSize = 0.0
        for ix in range(len(X)):
            winner = som.winner(X[ix])
            plt.text(
                winner[0] + (counterSize * [-1,1][random.randrange(2)] *.2), 
                winner[1] + (counterSize * [-1,1][random.randrange(2)] *.2), 
                baseFeaturesSet[ix], 
                bbox=dict(facecolor='white', alpha=0.55, lw=0)
            ) 
            counterSize+= 0.1
        plt.imshow(som.distance_map())
        plt.grid(False)
        plt.title(f'Self Organizing Maps | {nameTitle}', 
                  y=1.01, fontweight='bold', fontsize=12)
        plt.tight_layout()
        plt.show()
    
    # get the corresponding features
    selectedFeatures = []
    for ix in range(len(X)):
        winner = som.winner(X[ix])
        if winner[0] == winner[1]: selectedFeatures.append(baseFeaturesSet[ix])
    return selectedFeatures


######################################### LSTM CLASS ##############################################
class ExperimentLSTM(object):
    
    def __init__(self, dataset, timestep, labelName = 'Label'):
        self.features = dataset.loc[:, dataset.columns != labelName]
        self.labels = dataset[labelName]
        self.timestep = timestep
        self.labelName = labelName
        
    def __LSTMBaseNet__(self, nsteps, nfeatures, baseunits, dropout = 0):
        errMsg = \
        f"Error! 'dropout' regularization parameter should be between 0 and 1. Not {dropout}." 
        assert dropout <= 1, errMsg
        assert dropout >= 0, errMsg
        self.model = Sequential()
        self.model.add(
            LSTM(
                activation='sigmoid',
                units=baseunits, 
                input_shape = (nsteps, nfeatures),
                return_sequences=True, 
                dropout = dropout
            )
        )
        
    def __LayerDefinition__(self, units, dropout=0, complexityDense=True):
        self.model.add(
            LSTM(
                activation='sigmoid',
                units=units,
                return_sequences=True
            )
        )
        self.model.add(Dropout(dropout))
        if complexityDense: 
            self.model.add(Dense(10, activation='relu'))
        
    def __Dense__(self, units, activationFunc):
        self.model.add(
            Dense(
                units=units, 
                activation=activationFunc,
            )
        )
        
        
    def __Compiler__(self, lossFunc, optimizer, metricList):
        self.model.compile(
            loss=lossFunc,
            optimizer=optimizer,
            metrics=metricList
        )
        
    def __LSTMTraining__(self, X, y, 
                         epochs, batch_size,
                         validation_split = 0.2, verbose=0, shuffle=False):

        history = self.model.fit(
            X, y,
            epochs = epochs,
            validation_split=validation_split,
            batch_size=batch_size,
            shuffle=shuffle,
            verbose=verbose
        )
        return history
    
    def __LSTMEva__(self, X, y, verbose=0):
        metrics = self.model.evaluate(X, y, verbose=verbose, return_dict=True)
        return metrics
    
    def __traintestsplit__(self, split_size=0.8, scaling=True, scaling_range=(0,1)):
        # define size for split
        splitSize = int(self.features.shape[0]*split_size)
        
        # define X and Y train/test, and ingesting to the class
        X_train = self.features[:splitSize]
        X_test = self.features[splitSize:]
        y_train = self.labels[:splitSize]
        y_test = self.labels[splitSize:]
        
        # scaling procedure for training (fit and transform)
        if scaling:
            scalerObj = MinMaxScaler(feature_range=scaling_range)
            X_train = scalerObj.fit_transform(X_train) 
        
        # 2D to 3D transformation sample
        # >> forced reshaping based on samples timestep | Train set
        X_train_net, y_train_net = [], []
        observationLengthTrain = X_train.shape[0]
        for idx in range(self.timestep, observationLengthTrain+1):
            X_train_net.append(X_train[idx-self.timestep:idx])
            y_train_net.append(y_train[idx-1])
        
        
        if scaling: X_test = scalerObj.transform(X_test)
            
        # scaling procedure for testing (transform)          
        full_X_test = np.vstack((X_train[-self.timestep+1:], X_test))            
        
        # 2D to 3D transformation sample        
        # >> forced reshaping based on samples timestep | Test set   
        X_test_net, y_test_net = [], []
        observationLengthTest = full_X_test.shape[0]
        for idx in range(self.timestep, observationLengthTest+1):
            X_test_net.append(full_X_test[idx-self.timestep:idx])
            y_test_net.append(y_test[idx-self.timestep])
        
        # return subsets definition of Xtrain, ytrain, Xtest, ytest
        return (
            np.array(X_train_net), 
            np.array(y_train_net).reshape(-1,1), 
            np.array(X_test_net), 
            np.array(y_test_net).reshape(-1,1)
        ) 
    
    # main method: LSTM definition & training
    def compute_LSTM(self, 
                     layers,
                     baseunits, 
                     unitsList, 
                     activationFunc,                     
                     optimizer,                       
                     lossFunc, 
                     metricList,
                     split_size=0.8,
                     scaling=True,
                     scaling_range=(0,1),
                     train = True,
                     OOSeva = True,
                     epochs = 50, 
                     batch_size=100, 
                     dropout = 0, 
                     dropoutLayers = [None],
                     validation_split = 0.3, 
                     verbose=0, 
                     shuffle=False,
                     preserve_dropout=True,
                     complexityDense=False):
        
        # compute train/test split
        X_train, y_train, X_test, y_test = self.__traintestsplit__(split_size, scaling, scaling_range)
        
        # compute base LSTM net definition
        self.__LSTMBaseNet__(
            nsteps=X_train.shape[1], nfeatures=X_train.shape[2], 
            baseunits=baseunits, dropout=dropout
        )
        
        # check if layers is an integer, not float allowed
        assert type(layers) == int, "Number of layers should be a positive integer only."
        
        # check if layers is greater than zero
        assert layers>0, "Number of layers should be greater than 0."
        
        # check if layers (int) == length of unitsList
        assert len(unitsList) == layers, "Number of layers should be the same as elements in unitList."
        
        # check if layers (int) == length of dropoutlayers
        assert len(dropoutLayers) == layers, "Number of layers should be the same as elements in unitList."        
        
        # cancel dropout for extra layers, if is required
        if not preserve_dropout: dropout=0
        
        # iterative process to add layers to the LSTM base net
        if layers > 1:
            for layerIdx in range(1, layers+1):
                self.__LayerDefinition__(
                    units=unitsList[layerIdx-1], dropout=dropoutLayers[layerIdx-1], complexityDense=complexityDense
                )
        
        # set the final dense output layer
        self.__Dense__(units=1, activationFunc = activationFunc)
        
        # check that metricList should be a list object
        assert type(metricList) == list, "'metricList' should be a list only."
        
        # define the compiler of the model
        self.__Compiler__(lossFunc=lossFunc, optimizer=optimizer, metricList=metricList)
        
        # check if user requires train the model
        if train:
            # self compute the history of the model training process
            history = \
            self.__LSTMTraining__(
                X=X_train, 
                y=y_train, 
                epochs=epochs, 
                batch_size=batch_size, 
                validation_split=validation_split, 
                verbose=verbose, 
                shuffle=shuffle
            )      
            # check if the user requires OOS eva, only if train was activated as well
            if OOSeva:
                scoresEva = self.__LSTMEva__(X=X_test, y=y_test, verbose=verbose)
                return self.model, history, scoresEva
            
            # otherwise, return just model, training history, and tuple with train/test data 
            return self.model, history, (X_train, y_train, X_test, y_test)
        
        # if training is not activated, return just the empty no-trained LSTM model
        else:
            return self.model

        
def comparissonLSTM(assetName, 
                    runnings, 
                    dictInfo, 
                    modelSample,
                    colorLoss=('navy', 'darkgoldenrod'), 
                    colorAcc=('darkgreen', 'indianred')):
    
    fig, axes = plt.subplots(figsize=(15,15), nrows=2, ncols=2, sharex=True)

    exCounter = 0
    
    infoCriteriaDict = {}
    
    for keyWord, historyObjectList in dictInfo.items():
        # list of criterias per iteration
        learningConvergence, performanceCriteria1, performanceCriteria2 = [], [], []
        for historyObject in historyObjectList:
            axCoord = axes[exCounter]
            lossData = [value for key, value in historyObject.history.items() if 'loss' in key]
            accData = [value for key, value in historyObject.history.items() if 'acc' in key]
            # plot loss training sample
            axCoord[0].plot(lossData[0], color=colorLoss[0], linewidth=2)
            # plot loss validation sample
            axCoord[0].plot(lossData[1], color=colorLoss[1], linewidth=2)
            axCoord[0].set_title(f"Train vs. Validation | {keyWord} features - {assetName}", fontsize=14)
            # plot accuracy or evaluation metric training sample
            axCoord[1].plot(accData[0], color=colorAcc[0], linewidth=2)
            # plot accuracy or evaluation metric validation sample
            axCoord[1].plot(accData[1], color=colorAcc[1], linewidth=2)
            axCoord[1].set_title(f"Train vs. Validation | {keyWord} features - {assetName}", fontsize=14)
            # saving learning conv. crtiteria
            learningConvergence.append(
                np.mean(np.array(lossData[0])-np.array(lossData[1]))
            )
            # saving performance criteria 1
            performanceCriteria1.append(
                max(accData[1])
            )
            # saving performance criteria 2
            performanceCriteria2.append(
                accData[1][-1] - accData[1][0] 
            )
        # saving criterias info
        infoCriteriaDict[f"{keyWord}_lConv"] = learningConvergence
        infoCriteriaDict[f"{keyWord}_pHigh"] = performanceCriteria1
        infoCriteriaDict[f"{keyWord}_pSlope"] = performanceCriteria2
        exCounter+=1
    
    # encapsulate the criterias in a pandas dataframe
    criteriasDf = pd.DataFrame(infoCriteriaDict).rename_axis('Iteration')
    # print the sample model parametization
    print(f"  {assetName} | Fully vs. Frac  :::>>> Sample LSTM Model Configuration:\n")
    modelLayers = modelSample.get_config()['layers']
    printerObj = pprint.PrettyPrinter(depth=len(modelLayers)) 
    printerObj.pprint(modelLayers)
    print("**"*40)
    
    axes[1][0].set_xlabel('epochs')
    axes[1][1].set_xlabel('epochs')
    
    legAsset1 = mpatches.Patch(color=colorLoss[0], label=f'train loss')
    legAsset2 = mpatches.Patch(color=colorLoss[1], label=f'validation loss')
    legAsset3 = mpatches.Patch(color=colorAcc[0], label=f'train acc')
    legAsset4 = mpatches.Patch(color=colorAcc[1], label=f'validation acc')    
    plt.legend(
        handles=[legAsset1, legAsset2, legAsset3, legAsset4], 
        bbox_to_anchor=(1.05, 0.15), loc='upper left', borderaxespad=0
    )    
    plt.suptitle(
        f'LSTM Experiment | {assetName} - Runnings: {runnings}', 
                 y=1.002, fontsize=15, fontweight='bold')
    plt.tight_layout()
    plt.show()  
    
    # plotting evaluation criteria
    fig, axSet = plt.subplots(figsize=(15,5), nrows=1, ncols=3)
    criteriasDf.filter(regex='lConv').plot(ax=axSet[0], title='Learning Convergence')
    criteriasDf.filter(regex='pHigh').plot(ax=axSet[1], title='Performance Criteria | Accuracies')
    criteriasDf.filter(regex='pSlope').plot(ax=axSet[2], title='Performance Criteria | Slopes')
    plt.suptitle(
        f'Base Evaluation Criteria', 
                 y=1.0015, fontsize=12.5, fontweight='semibold')    
    plt.tight_layout()    
    plt.show()
    # computing stability criteria for each type of feature dataset
    for keyName in dictInfo.keys():
        print(f"::::::>>> Stability Criteria Value | {keyName}: ", np.std(criteriasDf[f"{keyName}_lConv"]))    